from django.db import models

# Create your models here.


class Livro(models.Model):

    nome_Autor = models.CharField(
        max_length=255,
        null=False,
        blank=False
    )

    nome_Livro = models.CharField(
        max_length=255,
        null=False,
        blank=False
    )

    ano_Lancamento = models.DateField(
        max_length=255,
        null=False,
        blank=False
    )

    isbn = models.CharField(
        max_length=13,
        null=False,
        blank=False
    )

    genero = models.CharField(
        max_length=255,
        null=False,
        blank=False
    )

    quantidade = models.IntegerField(
        default=0,
        null=False,
        blank=False
    )

    preco = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        null=False,
        blank=False
    )
