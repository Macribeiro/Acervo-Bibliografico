from django.shortcuts import render, redirect
from django.views.generic import ListView
from django.views.generic import CreateView
from acervobibliografico.models import Livro
from django.db import models
from django import forms
from acervobibliografico.forms import LivroForm
from django.views.generic import TemplateView
from django.views.generic import UpdateView
from django.views.generic import CreateView
from django.views.generic import ListView

# Create your views here.


class IndexTemplateView(TemplateView):
    template_name = 'website/home.html'
    model = Livro
    context_object_name = "home"


def update_livro(request, id):
    livro = Livro.objects.get(id=id)
    form = LivroForm(request.POST or None, instance=livro)

    if form.is_valid():
        form.save()
        return redirect('website:lista_livros')
    return render(request, 'website/InsereLivroForm.html', {'form': form, 'livro': livro})


def deleta_livro(request, id):
    livro = Livro.objects.filter(id=id)

    if request.method == 'POST':
        livro.delete()
        return redirect('website:lista_livros')

    return render(request, 'website/exclui.html', {'livro': livro})


def criar_Livros(request):
    form = LivroForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('website:lista_livros')

    return render(request, 'website/InsereLivroForm.html', {'form': form})


def lista_livros(request):
    livro = Livro.objects.all()
    return render(request, 'website/lista_livros.html', {'livro': livro})


class Home(ListView):
    template_name = 'website/home.html'
    model = Livro
    context_object_name = 'home'
